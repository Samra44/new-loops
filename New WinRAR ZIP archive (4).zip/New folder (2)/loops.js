// while loops 
// let num1 = 1;
// while (i<=10){

// }



// for loops

// const weekdays = ['saturday' , 'Sunday' , 'Monday' , 'Tuesday', 'wednesday', 'Thursday', 'Friday' ];

// for (let i = 0; i  < weekdays.lenghth; i++){
//     console.log (weekdays[i]);

// }

// for of javascript

// for (const i of "javascript"){
//     console.log(i);
// }



// Do while loops

// let i=5;
// do{console.log("print table of 5",1)
//    i=i+5
// }while (i<=50)
